# eTools
## Live Site Link: [https://etools-f14f3.web.app/](https://etools-f14f3.web.app/)

## Install
    -npm install firebase
    -npm install -D tailwindcss
    -npm i daisyui
    -npm install react-icons --save
    -npm install react-router-dom@6
    -npm install react-multi-carousel --save
    -npm install --save aos@next

    
    

