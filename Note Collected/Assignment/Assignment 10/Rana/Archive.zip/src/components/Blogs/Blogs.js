import React from 'react';
import './Blogs.css'
const Blogs = () => {
    return (
        <div>
            <h2>Blogs</h2>
        </div>
    );
};

export default Blogs;