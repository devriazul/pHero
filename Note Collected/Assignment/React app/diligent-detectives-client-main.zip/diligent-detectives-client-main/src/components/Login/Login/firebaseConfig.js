const firebaseConfig = {
  apiKey: "AIzaSyA5XyJvWdUgFxSsp4Iq9cTsNACZ2fSmgwk",
  authDomain: "diligent-detectives.firebaseapp.com",
  projectId: "diligent-detectives",
  storageBucket: "diligent-detectives.appspot.com",
  messagingSenderId: "634378328899",
  appId: "1:634378328899:web:90467d9ca0377edc29edf6"
};

  export default firebaseConfig;