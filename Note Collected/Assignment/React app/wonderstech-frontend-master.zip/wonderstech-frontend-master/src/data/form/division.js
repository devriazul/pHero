const divisions = [
  "Dhaka",
  "Barishal",
  "Chattogram",
  "Khulna",
  "Mymensingh",
  "Rajshahi",
  "Rangpur",
  "Sylhet",
];

export default divisions;
