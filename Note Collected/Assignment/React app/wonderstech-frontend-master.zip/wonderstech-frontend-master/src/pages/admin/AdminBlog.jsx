import React from "react";
import LayoutAdmin from "../../layouts/LayoutAdmin";

const AdminBlog = () => {
  return (
    <LayoutAdmin>
      <h1>Admin blog actions</h1>
    </LayoutAdmin>
  );
};

export default AdminBlog;
